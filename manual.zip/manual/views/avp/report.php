<!DOCTYPE html>
<html lang="en">

<body>
    <div class="container">
        <ol>
            <p class="h4 mb-2">Report Permintaan</p>
            <hr class="mb-5">
            <p>Ketika baru pertama kali masuk, user akan diarahkan ke dalam halaman dashboard. Ada beberapa komponen dalam dashboard, yakni teks selamat datang berisi informasi akun yang login, dan berisi informasi - informasi yang telah tercatat dalam sistem LURA. Berikut adalah tampilan dashboard LURA :</p>
            <img src="assets/img/avp/menu-report.png" alt="Pencarian" class="rounded img-fluid">
            <p class="mb-5">Gambar diatas adalah teks yang berisi informasi akun yang sedang login.</p>

            <hr>
            <img src="assets/img/avp/filter-cetak-report.png" alt="Pencarian" class="rounded img-fluid">

            <hr>
            <img src="assets/img/avp/tanggal-report.png" alt="Pencarian" class="rounded img-fluid">

            <hr>
            <img src="assets/img/avp/filter-report.png" alt="Pencarian" class="rounded img-fluid">

            <hr>
            <img src="assets/img/avp/print-report.png" alt="Pencarian" class="rounded img-fluid">
        </ol>
    </div>
</body>

</html>