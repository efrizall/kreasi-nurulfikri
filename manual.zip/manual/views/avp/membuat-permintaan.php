<!DOCTYPE html>
<html lang="en">

<body>
    <div class="container">
        <ol>
            <p class="h4 mb-2">Membuat Permintaan</p>
            <hr class="mb-5">
            <img src="assets/img/avp/tombol-tambah-permintaan.png" alt="Pencarian" class="rounded img-fluid mb-3" style="max-width: 80%;">
            <p>Untuk membuat permintaan, AVP dapat memilih menu permintaan pada menu di atas. Terdapat beberapa pilihan yaitu maintenance, transportasi, dan ekspedisi</p>


            <p class="mb-5">Kemudian klik tombol permintaan layanan. Ketika diklik, AVP akan diarahkan pada form untuk mengisi data permintaan layanan seperti gambar dibawah ini.</p>

            <hr>
            <img src="assets/img/avp/form-tambah.png" alt="Pencarian" class="rounded img-fluid mb-3" style="max-width: 80%;">

            <p class="mb-3">Ada beberapa yang perlu AVP isi seperti nama, permintaan layanan, divisi, keterangan atau barang (optional), tanggal permintaan, pemeriksa surat, dan lampiran file <b>jika ada</b></p>

            <p class="mb-5">Jika sudah terisi, AVP dapat menyimpannya dengan menekan tombol <b>simpan</b>, jika tidak ingin menambahkan AVP dapat menekan tombol <b>batal</b></p>


        </ol>
    </div>
</body>

</html>