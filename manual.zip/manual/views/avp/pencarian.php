<!DOCTYPE html>
<html lang="en">

<body>
    <div class="container">
        <ol>
            <p class="h4 mb-2">Mencari Data</p>
            <hr class="mb-5">

            <img src="assets/img/avp/pencarian.png" alt="Pencarian" class="rounded img-fluid mb-3" style="max-width: 80%;">
            <p>Pada kolom informasi diatas, terdapat fitur pencarian untuk AVP mencari data yang ingin dicari.</p>
            <p class="mb-5">Kemudian AVP hanya memasukkan kata kunci yang ingin di cari saja, lalu tekan <b>enter</b> atau klik <b>tombol cari</b> disamping kiri.</p>

            <hr>
            <img src="assets/img/avp/hasil-pencarian.png" alt="Pencarian" class="rounded img-fluid mb-3" style="max-width: 80%;">
            <p class="mb-5">Jika ditekan tombol cari, maka akan keluar hasil dari kata kunci tersebut seperti gambar diatas.</p>
        </ol>
    </div>
</body>

</html>